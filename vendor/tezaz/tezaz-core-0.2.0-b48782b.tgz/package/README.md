# @tezaz/core

Browser client for Tezaz: a visitor speaks or types to an assistant on your page, and the
assistant calls functions you register — with typed, validated arguments, and confirmation
for anything risky — instead of just chatting.

Framework-agnostic. `@tezaz/react` adds a ready-made widget; `@tezaz/vue` and
`@tezaz/svelte` add the same client through each framework's lifecycle.

## Install

```sh
npm install @tezaz/core
```

## Use

```ts
import { createTezaz } from '@tezaz/core';

const client = createTezaz({
  relayUrl: 'wss://relay.example/v1/session',
  token: () => fetch('/my/tezaz-token').then((r) => r.text()),
  language: 'am-ET',
});

client.register({
  name: 'add_to_cart',
  description: 'Add a product to the shopping cart.',
  parameters: {
    type: 'object',
    properties: {
      product: { type: 'string' },
      quantity: { type: 'integer', minimum: 1 },
    },
    required: ['product', 'quantity'],
  },
  handler: ({ product, quantity }) => cart.add(product, quantity),
});

client.connect().catch(console.error);
```

Capabilities marked `confirm` or `dangerous` show the visitor the exact final arguments in
your own UI (via the `confirm` option) before they run — the model never acts on something
the visitor hasn't approved.

`relayUrl` has to point at a Tezaz relay you run yourself; there is no managed, hosted relay
yet.
