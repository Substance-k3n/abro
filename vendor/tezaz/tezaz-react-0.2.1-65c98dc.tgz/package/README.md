# @tezaz/react

Tezaz for React: a provider, a `useCapability` hook, and a complete, ready-made voice
widget — launcher, panel, microphone, text input and confirmation dialog.

## Install

```sh
npm install @tezaz/react
```

## Use

```tsx
import { TezazProvider, TezazWidget, useCapability } from '@tezaz/react';

export function Root() {
  return (
    <TezazProvider
      relayUrl="wss://relay.example/v1/session"
      token={() => fetch('/my/tezaz-token').then((r) => r.text())}
      language="am-ET"
    >
      <App />
      <TezazWidget />
    </TezazProvider>
  );
}

// In any component: an action the assistant may run while it's on screen.
function Cart() {
  useCapability({
    name: 'add_to_cart',
    description: 'Add a product to the shopping cart.',
    parameters: {
      type: 'object',
      properties: { product: { type: 'string' }, quantity: { type: 'integer', minimum: 1 } },
      required: ['product', 'quantity'],
    },
    handler: ({ product, quantity }) => cart.add(product, quantity),
  });
  // …
}
```

`<TezazWidget project="tz_pub_…" />` loads the look published on the console's Widget page,
so it changes without a deploy (ADR-008). A tap on the launcher opens the voice card by
default; `panel` (`true`, or `'desktop'` for computers only) opens the chat panel instead, and
the layouts below are the panel's. Props still win: `panel`, `variant` (`panel`, `compact`,
`voice`), `position`, `offset`, `colorScheme`, `theme` (including `accent2` for a gradient),
`launcher` (size, shape, label), `radius`, `mark`, `logo`, `font`, `backdrop` (`light`: an
animated WebGL2 light behind the header, a still gradient without WebGL2), `typing`, `motion` and
`strings`, or a whole `appearance` object. No CSS required, but every visual detail is
overridable. When the assistant runs an action, a chip floats up beside the widget. With
`focus` (on by default for `voice`), turning the microphone on in the panel opens a full-screen view: the orb
in the middle, live captions, and microphone, back-to-chat and end buttons. By default the
microphone takes one command and turns off (`afterCommand="stop"`), reopening only if the
assistant needs an answer; `afterCommand="listen"` keeps it on for a conversation.

`relayUrl` has to point at a Tezaz relay you run yourself; there is no managed, hosted relay
yet.
